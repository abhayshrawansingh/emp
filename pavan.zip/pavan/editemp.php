<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Employee Information Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            display: flex;
            align-items: center;
            padding: 10px 0;
            width: 100%;
        }

        .pavan-logo {
            width: 80px;
            height: 80px;

            border-radius: 50%;
            margin-left: 20px;
        }

        .pavan-logo img {
            border-radius: 50%;
        }

        .pavan-heading {
            margin-left: 20px;
        }

        header h1 {
            margin: 0;
        }

        header h2 {
            margin: 5px 0 0;
            font-size: 1.2em;
        }  
          header h1 {
            text-align: center;
            color: #ffffff;

        }



        .container {
            max-width: 500px;
            margin: 30px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

            .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="tel"],
        .form-group input[type="number"],
        .form-group input[type="file"],
        .form-group input[type="email"],
        .form-group input[type="date"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .form-group input[type="file"] {
            padding: 0;
        }

        .form-group .image-preview {
            display: block;
            max-width: 150px;
            margin-top: 10px;
        }

        .form-group input[type="file"]:not(:empty)~.image-preview {
            display: block;
        }

        .form-group .image-preview {
            display: none;
        }

        .form-group button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }
        .back_button{
            margin:20px;
            position:fixed;
            top:90px;
            right: 0;
        }
        .back_button button{
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        .back_button button:hover {
            background-color: #0056b3;
        }
        .s-input{
        max-width: 500px;
        margin: 30px;
        font-weight: bold;
       
    }
    .s-input input{
        width: 250px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
            margin-top: 10PX;
    }
    .s-input label{
        font-size: 19px;
    }
    .s-input button{
        background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
    }
    .s-input button:hover {
            background-color: #0056b3;
        }
        .s-input input::-webkit-inner-spin-button {
    -webkit-appearance: none;
}

        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 10px;
                margin: 30px;
            }
            header{
                width: 100%;
            }

            header h1 {
                font-size: 20px;

            }

            header h2 {
                font-size: 13px;
            }
        }
    </style>
</head>

<body>
    <header>
       <?php 
       include "header.php";
       ?>
    </header>
    <section class="s-input">
        <label>Enter Employee Id Number:</label><br>
        <input type="number" placeholder="Id Number">
        <button type="submit">Submit</button>
    </section>
    <div class="alert alert-success" role="alert" style="display:none">
  A simple success alert—check it out!
</div>
<div class="back_button"><button>Back</button></div>
    <div class="container">
        <h1>Edit Employee Info Here</h1>
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Employee Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="phone">Employee Phone Number:</label>
                <input type="tel" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" required>
            </div>
            <div class="form-group">
                <label for="adhar">Aadhar Number:</label>
                <input type="number" id="adhar" name="adhar" required>
            </div>
            <div class="form-group">
                <label for="pan">PAN Card Number:</label>
                <input type="text" id="pan" name="pan" >
            </div>
            <div class="form-group">
                <label for="account">Bank Account Number:</label>
                <input type="number" id="account" name="account" >
            </div>
            <div class="form-group">
                <label for="ifsc">IFSC Code:</label>
                <input type="text" id="ifsc" name="ifsc">
            </div>
            <div class="form-group">
                <label for="salary">Salary:</label>
                <input type="number" id="salary" name="salary" required>
            </div>
            <div class="form-group">
                <label for="joining-date">Joining Date:</label>
                <input type="date" id="joining-date" name="joining_date" required>
            </div>
            <div class="form-group">
                <label for="image">Employee Image (Passport Size):</label>
                <input type="file" class="form-control" name="avatar" accept="image/*" required>
                <!-- <img id="image-preview" class="image-preview" alt="Image Preview"> -->
            </div>
            <div class="form-group">
                <button type="submit" name="btn">Submit</button>
                
            </div>
        </form>
     
    </div>

</body>

</html>