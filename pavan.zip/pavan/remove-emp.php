<?php
session_start();
$pavan = $_SESSION['pavanusername'];
if (!isset($pavan)) {
    header("Location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remove-emp</title>
</head>
<style>
    * {
        margin: 0;
        padding: 0;
    }

    header {
        background-color: #333;
        color: #fff;
        display: flex;
        align-items: center;
        padding: 10px 0;

    }

    .pavan-logo {
        width: 80px;
        height: 80px;

        border-radius: 50%;
        margin-left: 20px;
    }

    .pavan-logo img {
        border-radius: 50%;
    }

    .pavan-heading {
        margin-left: 20px;
    }

    header h1 {
        margin: 0;
        color: white;
    }

    header h2 {
        margin: 5px 0 0;
        font-size: 1.2em;
    }

    .s-input {
        max-width: 500px;
        margin: 30px;
        font-weight: bold;

    }

    .s-input input {
        width: 250px;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        box-sizing: border-box;
        font-size: 16px;
        margin-top: 10PX;
    }

    .s-input label {
        font-size: 19px;
    }

    .s-input button {
        background-color: #007BFF;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        border-radius: 4px;
        cursor: pointer;
        margin-top:7px;
    }

    .s-input button:hover {
        background-color: #0056b3;
    }
    .s-input input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    }

    .container {
        max-width: 1200px;
        margin: 50px auto;
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #333;
        margin-bottom: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    table,
    th,
    td {
        border: 1px solid #ddd;
    }

    th,
    td {
        padding: 10px;
        text-align: left;
    }

    th {
        background-color: #f4f4f4;
        font-weight: bold;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    @media (max-width: 768px) {

        header h1 {
            font-size: 20px;

        }

        header h2 {
            font-size: 13px;
        }

        table {
            border: 0;
        }

        thead {
            display: none;
        }

        tr {
            border-bottom: 2px solid #ddd;
            display: block;
            margin-bottom: 10px;
        }

        td {
            display: block;
            text-align: right;
            padding: 10px;
            position: relative;
            border: none;
        }

        td::before {
            content: attr(data-label);
            position: absolute;
            left: 0;
            width: 45%;
            padding-left: 10px;
            font-weight: bold;
            white-space: nowrap;
            text-align: left;
        }

        td:last-child {
            border-bottom: 0;
        }

        .container {
            margin: 20px;
        }
    }

    .delete-button {
        max-width: 100%;
        text-align: center;
    }

    .delete-button button {
        background-color: #ff2a00;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        border-radius: 4px;
        cursor: pointer;
    }

    .delete-button button:hover {
        background-color: #e62b16;
    }

    /* .back_button{
            margin:20px;
           width: 100%;
            height: auto;
            text-align: center;
        }
        .back_button button{
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        .back_button button:hover {
            background-color: #0056b3;
        } */
</style>

<body>
    <header>
       <?php 
       include "header.php";
       ?>
    </header>

    <main>
        <section class="s-input">
            <label>Enter Employee Id Number:</label><br>
            <form method="post">
                <input type="number" placeholder="Id Number" name="id" required>
                <button type="submit" name="search">Submit</button>
            </form>
        </section>
        <div class="container">
            <h1>Employee Information</h1>
            <table>
                <thead>
                    <tr>
                        <th>Id No</th>
                        <th>Name</th>
                        <th>Phone Number</th>



                    </tr>
                </thead>
                <tbody>
                    <!-- Sample Data (replace with dynamic data) -->
                    <?php
                    if (isset($_POST['search'])) {
                        $id = $_POST['id'];
                        include 'dbconnection.php';
                        include 'removeBackend.php';
                        $ResultSet = dellInfo($id);
                        $rs=checkEmpPresent($conn,$id);
                       if($rs[0]==0){
                            echo "<script>alert('Employee Not Found.');</script>";
                        }
                        while ($rs = mysqli_fetch_row($ResultSet)) {
                    ?>

                            <tr>
                                <td data-label="Id No"><?php echo $rs[0]; ?></td>
                                <td data-label="Name"><?php echo $rs[1]; ?></td>
                                <td data-label="Phone Number"><?php echo $rs[2]; ?></td>
                            </tr>
                    <?php
                        }
                    }
                    ?>

                    <!-- Repeat the <tr> block for more employees -->
                </tbody>
            </table>
        </div>
        <div class="delete-button">
            <form method="post"><button type="submit" name="del" value=<?php if (isset($_POST['search'])) {
                                                                            echo $_POST['id'];
                                                                        } 
                                                                        else echo 0; ?>>Delete</button></form>
            <div class="back_button" style="margin: 20px;"><button style="background-color: rgb(0, 89, 255);  " onclick="homeRedirect()">Back</button></div>
        </div>
        <?php
        if (isset($_POST['del'])) {
            include 'removeBackend.php';
            include 'dbconnection.php';
            $id = $_POST['del'];
            $rs=checkEmpPresent($conn,$id);
            if ($id == 0) {
                echo "<script>alert('Please Enter Employee Id.');</script>";
            }
            else if($rs[0]==0){
                echo "<script>alert('Employee Not Found.');</script>";
            }
            else{
                empDel($id);
                echo "<script>window.alert('Delete Succusfully.');window.location.href='remove-emp.php';</script>";
            }
        }
        ?>
    </main>
    <script>
        function homeRedirect() {
            window.location.href = 'home.php';
        }
    </script>
</body>

</html>