<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Table</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .table-container {
            width: 100%;
            overflow-x: auto; /* Allows horizontal scrolling on smaller devices */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            min-width: 400px; /* Ensures minimum width for the table */
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
        }

        @media screen and (max-width: 600px) {
            table, tbody, th, td, tr {
                display: block;
            }

            thead tr {
                display: none; /* Hide header on smaller screens */
            }

            tr {
                margin-bottom: 15px;
            }

            td {
                text-align: right;
                padding-left: 50%;
                position: relative;
            }

            td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                width: 50%;
                padding-right: 10px;
                white-space: nowrap;
                text-align: left;
                font-weight: bold;
            }
        }
    </style>
</head>
<body>
    <header>
        <?php
        include "header.php";
        ?>
    </header>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Check-in Time</th>
                    <th>Check-out Time</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td data-label="Employee ID">101</td>
                    <td data-label="Name">John Doe</td>
                    <td data-label="Date">2024-09-10</td>
                    <td data-label="Check-in Time">08:30 AM</td>
                    <td data-label="Check-out Time">05:00 PM</td>
                </tr>
                <tr>
                    <td data-label="Employee ID">102</td>
                    <td data-label="Name">Jane Smith</td>
                    <td data-label="Date">2024-09-10</td>
                    <td data-label="Check-in Time">09:00 AM</td>
                    <td data-label="Check-out Time">05:30 PM</td>
                </tr>
                <!-- More rows as needed -->
            </tbody>
        </table>
    </div>
</body>
</html>
