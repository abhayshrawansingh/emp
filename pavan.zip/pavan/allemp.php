<?php
session_start();
$pavan = $_SESSION['pavanusername'];
if (!isset($pavan)) {
    header("Location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Information Table</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            display: flex;
            align-items: center;
            padding: 10px 0;

        }

        .pavan-logo {
            width: 80px;
            height: 80px;

            border-radius: 50%;
            margin-left: 20px;
        }

        .pavan-logo img {
            border-radius: 50%;
        }

        .pavan-heading {
            margin-left: 20px;
        }

        header h1 {
            margin: 0;
        }

        header h2 {
            margin: 5px 0 0;
            font-size: 1.2em;
        }



        header h1 {
            text-align: center;
            color: #ffffff;

        }

        .container {
            max-width: 1200px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .back_button {
            margin: 20px;

        }

        .back_button button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        .back_button button:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            header h1 {
                font-size: 20px;

            }

            header h2 {
                font-size: 13px;
            }

            table {
                border: 0;
            }

            thead {
                display: none;
            }

            tr {
                border-bottom: 2px solid #ddd;
                display: block;
                margin-bottom: 10px;
            }

            td {
                display: block;
                text-align: right;
                padding: 10px;
                position: relative;
                border: none;
            }

            td::before {
                content: attr(data-label);
                position: absolute;
                left: 0;
                width: 45%;
                padding-left: 10px;
                font-weight: bold;
                white-space: nowrap;
                text-align: left;
            }

            td:last-child {
                border-bottom: 0;
            }

            .container {
                margin: 20px;
            }
        }
    </style>
</head>

<body>
    <header>
       <?php 
       include "header.php";
       ?>
    </header>
    <div class="back_button"><button onclick="homeRedirect()">Back</button></div>
    <div class="container">
        <h1>Employee Information</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Address</th>
                    <th>Aadhar Number</th>
                    <th>PAN Card Number</th>
                    <th>Bank Account Number</th>
                    <th>IFSC Code</th>
                    <th>Salary</th>
                    <th>Joining Date</th>
                </tr>
            </thead>
            <tbody>
                <!-- Sample Data (replace with dynamic data) -->
                <?php
                include 'db.php';
                $ResultSet = allDetails($conn);
                ?>
                <?php while ($rs = mysqli_fetch_row($ResultSet)) { ?>
                    <tr>
                        <td data-label='Id'><?php echo $rs[0]; ?></td>
                        <td data-label='Name'><?php echo $rs[1]; ?></td>
                        <td data-label='Phone Number'><?php echo $rs[4]; ?></td>
                        <td data-label='Address'><?php echo $rs[5]; ?></td>
                        <td data-label='Aadhar Number'><?php echo $rs[6]; ?></td>
                        <td data-label='PAN Card Number'><?php echo $rs[7]; ?></td>
                        <td data-label='Bank Account Number'><?php echo $rs[14]; ?></td>
                        <td data-label='IFSC Code'><?php echo $rs[15]; ?></td>
                        <td data-label='Salary'>$<?php echo $rs[10]; ?></td>
                        <td data-label='Joining Date'><?php echo $rs[11]; ?></td>
                    </tr>
                <?php } ?>
                <!-- Repeat the <tr> block for more employees -->
            </tbody>
        </table>
    </div>
    <script>
        function homeRedirect() {
            window.location.href = 'home.php';
        }
    </script>
</body>

</html>