<?php
session_start();
$pavan = $_SESSION['pavanusername'];
if (!isset($pavan)) {
    header("Location:index.php");
}
?>
<?php
if (isset($_POST['download'])) {
    include('fpdf.php');
    include('../db.php');
    $id=$_POST['download'];
    $image=getImage($conn,$id);
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->Rect(10, 10, 100, 150);
    $pdf->Image("PE.png", 10, 10, 15, 15);
    $pdf->SetFont("Arial", "B", 16);
    $pdf->Cell(100, 13, "         Pavan Engineering Company", 1, "L");
    $pdf->ln();
    $pdf->Image("../$image", 35.3, 25, 50, 50);
    $pdf->ln(45);
    $pdf->SetFont("Arial", "B", 14);
    $pdf->Cell(20, 13, "  Name:- ", 0, 0, "L");
    $pdf->Cell(80, 13, "      Abhay Singh ", 0, 0, "L");
    $pdf->ln();
    $pdf->Cell(20, 13, "  ID:- ", 0, 0, "L");
    $pdf->Cell(80, 13, "      $id ", 0, 0, "L");
    $pdf->ln();
    $pdf->Image("barcode.jpg", 13, 110, 94, 20);
    $pdf->Output();
}
