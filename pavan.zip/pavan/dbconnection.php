<?php
$servername = "localhost";
$username = "root";
$password = "";
$db="pavan";

// Create connection
$conn =mysqli_connect($servername, $username, $password,$db);
?>