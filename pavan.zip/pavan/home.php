<?php include 'db.php'; ?>
<?php
    session_start();
    if (!isset($_SESSION['pavanusername'])) {
    header("Location:index.php");
    }
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Employee Attendance System</title>
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <header>
          <?php
          include "header.php";
          ?>
        </header>

        <main>
            <section class="employee-info">
                <div id="employeeDetails">
                    <?php
                    if (isset($_POST['bar'])) {
                        $id = $_POST['bar'];

                        // Start Check in And Check Out

                        include 'checkin.php';
                        if (isPresentEmp($id)) {
                            if (isNotCheckIn($id)) {
                                date_default_timezone_set('Asia/Kolkata');
                                $check_in = date('H:i:s');
                                $flag = date('H');
                                $date = date('Y-m-d');
                                $time = date('H:i:s');
                                $sql = "insert into check_in_out(date,check_in,flag,time,barcode) values('$date','$check_in',$flag,'$time',$id)";
                                $ResultSet = mysqli_query($conn, $sql);
                            } else {
                                //flag and update
                                $flag = getFlag($id);
                                date_default_timezone_set('Asia/Kolkata');
                                $time = date('H');
                                $date = date('Y-m-d');
                                $t = date('H:i:s');
                                $time2 = date('H:i:s');
                                if ($time >= ($flag + 2)) {
                                    $sql = "update check_in_out set check_out='$t' where date='$date' and barcode='$id'";
                                    $ResultSet = mysqli_query($conn, $sql);
                                    $sql = "update check_in_out set time='$time2' where date='$date' and barcode='$id'";
                                    $ResultSet = mysqli_query($conn, $sql);
                                }
                            }
                        }



                        // End Check in and Check Out



                    } ?>
                    <img src="<?php if (isset($_POST['bar'])) {
                                    echo getImage($conn, $id);
                                } else {
                                    echo 'https://png.pngtree.com/png-vector/20190710/ourmid/pngtree-user-vector-avatar-png-image_1541962.jpg';
                                } ?>" alt="Photo Unavailble" id="employeePhoto">
                    <div id="employeeData">
                        <h4 id="employeeName"></h4>

                        <p id="employeeDetailsText">Name: <span id="employeeNameText"><?php if (isset($_POST['bar'])) {
                                                                                            echo getName($conn, $id);
                                                                                        } ?></span></p>
                        <p id="employeeDetailsText">ID No: <span id="employeeIdText"><?php if (isset($_POST['bar'])) {
                                                                                            echo $_POST['bar'];
                                                                                        } ?></span></p>
                    </div>
                </div>
            </section>

            <section class="scanner" >
                <h3>Scan Employee Barcode</h3>
                <form name="pos" action="home.php" method="post" onload="document.bar.focus()" id="myform">
                    <input type="text" name="bar" id="barcodeInput" placeholder="Scan barcode here" onkeyup="document.getElementById('myform').submit();" autofocus>
                </form>
            </section>

            <div class="search-logs">
                <h3>Employee Logs</h3>
                <form method="post">
                    <div class="search-controls">
                        <input type="text" name="empid" id="searchInput" placeholder="Search By Employee Id" required>
                        <input type="date" name="from" id="startDate" placeholder="Start Date" required>To
                        <input type="date" name="to" id="endDate" placeholder="End Date" required>
                        <button name="searchBtn">Search</button>
                    </div>
                </form>
                <table id="logsTable">
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Name</th>
                            <th>Date</th>
                            <th>Check-in Time</th>
                            <th>Check-out Time</th>
                        </tr>
                        <?php
                        include 'printLogDetails.php';
                        ?>
                        <?php
                        if (isset($_POST['searchBtn'])) {
                            $empid = $_POST['empid'];
                            $from = $_POST['from'];
                            $to = $_POST['to'];
                            include 'removeBackend.php';
                            $rs = checkEmpPresent($conn, $empid);
                            if ($rs[0] == 0) {
                                echo "<script>alert('Employee Not Found.');</script>";
                            } else {
                                $ResultSet = getLogDetails($empid, $from, $to);
                                while ($rs = mysqli_fetch_row($ResultSet)) { ?>
                                    <tr>
                                        <td><?php echo $rs[0]; ?></td>
                                        <td><?php echo $rs[1]; ?></td>
                                        <td><?php echo $rs[4]; ?></td>
                                        <td><?php echo $rs[5]; ?></td>
                                        <td><?php echo $rs[6]; ?></td>
                                    </tr>

                        <?php }
                            }
                        }
                        ?>

                        <?php
                        if(!isset($_POST['searchBtn'])){
                        $ResultSet = getTopFive();
                        while ($rs = mysqli_fetch_row($ResultSet)) { ?>
                            <tr>
                                <td><?php echo $rs[0]; ?></td>
                                <td><?php echo $rs[1]; ?></td>
                                <td><?php echo $rs[2]; ?></td>
                                <td><?php echo $rs[3]; ?></td>
                                <td><?php echo $rs[4]; ?></td>
                            </tr>
                        <?php }}
                        ?>
                    </thead>
                    <tbody>
                        <!-- Logs will be dynamically inserted here -->
                    </tbody>
                </table>
                </section>



                <section class="actions">
                    <button id="addEmployeeBtn" onclick="addEmp()">Add Employee</button>
                    <button id="viewAllEmployeesBtn" onclick="viewAll()">View All Employees</button>
                    <button id="delemp" onclick="delemp()">Delete Employee</button>
                    <button id="down_card" onclick="window.location.href='emp.php';">Download Id-Card</button>
                     <button id="" onclick="">Log Info</button>
                     <button id="" onclick="">Edit</button>
                </section>
        </main>

        <script src="JavaScript/script.js">

        </script>
    </body>

    </html>