
function addEmp() {
    window.location.href = 'addemp.php';
}
function viewAll(){
    window.location.href='allemp.php';
}

function delemp(){
    window.location.href = 'remove-emp.php';
}
function addemp() {
    window.location.href = 'emp.php';
}
function homeRedirect(){
    window.location.href='home.php';
}
function down_card(){
    window.location.href='home.php';
}

