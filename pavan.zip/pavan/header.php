<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pavan Engineering Company - Employee Attendance System</title>
    <style>
        /* General Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background-color: #333;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 5px;
            width: 100%; /* Make header width 97% */
            margin: 0 auto; /* Center the header */
            position: relative;
            box-sizing: border-box;
        }

        .pavan-logo {
            width: 70px;
            height: auto;
            max-width: 10vw; /* Responsive width */
            border-radius: 50%;
            overflow: hidden;
        }

        .pavan-logo img {
            width: 100%;
            height: auto;
            display: block;
        }

        .pavan-heading {
            flex-grow: 1;
            text-align: center;
            padding: 0 10px;
        }

        .pavan-heading h1, .pavan-heading h2 {
            margin: 0;
            font-size: 1.2rem; /* Responsive font size */
        }

        .pavan-heading h1 {
            font-size: 1.5rem; /* Responsive font size */
        }

        .pavan-heading h2 {
            font-size: 1rem; /* Responsive font size */
        }

        /* Desktop Dropdown Menu */
        .desktop-menu {
            display: none;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .desktop-menu li {
            display: inline-block;
            margin-left: 20px;
        }

        .desktop-menu li a {
            color: #fff;
            text-decoration: none;
            padding: 10px;
            font-size: 1rem; /* Responsive font size */
        }

        .desktop-menu li a:hover {
            background-color: #555;
            border-radius: 4px;
        }

        /* Hamburger Menu */
        .hamburger {
            display: none;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }

        .hamburger div {
            width: 30px;
            height: 3px;
            background-color: #fff;
            margin: 4px 0;
            transition: all 0.3s ease;
        }

        .mobile-menu {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #333;
            width: 200px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            list-style: none;
            margin: 0;
            padding: 10px 0;
            transition: transform 0.3s ease;
            transform: translateX(100%);
            z-index: 10;
        }

        .mobile-menu.open {
            display: block;
            transform: translateX(0);
        }

        .mobile-menu li {
            text-align: right;
        }

        .mobile-menu li a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
            font-size: 1rem; /* Responsive font size */
        }

        .mobile-menu li a:hover {
            background-color: #555;
        }

        /* Responsive Design */
        @media (min-width: 768px) {
            .desktop-menu {
                display: block;
            }

            .hamburger {
                display: none;
            }

            .mobile-menu {
                display: none;
            }
        }

        @media (max-width: 768px) {
            
            .hamburger {
                display: flex;
            }

            .pavan-heading h1 {
                font-size: 1.2rem; /* Smaller font for smaller screens */
                margin-right:20px;
            }

            .pavan-heading h2 {
                font-size: 0.9rem; /* Smaller font for smaller screens */
                 margin-right:20px;
            }

            .mobile-menu {
                width: 70%; /* Make the menu smaller on smaller screens */
                right: 0; /* Align to the right */
            }
        }
    </style>
</head>
<body>

<header>
    <div class="pavan-logo"><img src="image/PE.png" alt="Pavan Engineering Logo"></div>
    <div class="pavan-heading">
        <h1>Pavan Engineering Company</h1>
        <h2>Employee Attendance System</h2>
    </div>
    <!-- Desktop Menu -->
    <ul class="desktop-menu">
        <li><a href="logout.php">Logout</a></li>
    </ul>

    <!-- Hamburger Menu -->
    <div class="hamburger" onclick="toggleMenu()">
        <div></div>
        <div></div>
        <div></div>
    </div>
    <!-- Mobile Menu -->
    <ul class="mobile-menu" id="mobileMenu">
        <li><a href="logout.php">Logout</a></li>
    </ul>
</header>

<script>
    function toggleMenu() {
        const mobileMenu = document.getElementById('mobileMenu');
        mobileMenu.classList.toggle('open');
    }
</script>

</body>
</html>
